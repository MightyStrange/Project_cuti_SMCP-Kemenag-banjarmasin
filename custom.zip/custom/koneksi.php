<?php
$koneksi = mysqli_connect("localhost","root","","cuti_laporan"); 
?>