<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <link rel="stylesheet" type="text/css" href="laporan2.css"/>
  <title>Laporan Polisi</title></head>
  <body>

    <div style="text-align:center; ">
      <img src="image/jambispirit.jpg" height="100px" width="200px"/><br/>
      <b>LAPORAN CONTOH</b>
      <hr  width="200px"/>
      001/II/JS
    </div>

    <table width="100%" border="1">

      <tr>
        <td valign="top">
         <strong>Sample </strong></td>
         <td valign="top" align="justify">Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample Sample </td>
       </tr>

       <tr>
        <td valign="top">
          <strong>Sample</strong></td>
          <td valign="top" align="justify">Sample </td>
        </tr>

        <tr>
          <td width="23%" valign="top">
            <b>Sample</b></td>
            <td width="77%" valign="top" align="justify">Sample <br/></td>
          </tr>

          <tr>
            <td colspan="2" valign="top" align="justify">
              Demikianlah Laporan ini dibuat dengan yang sebenarnya,_ _ _ _ _ _ _ _ _ _ _       
            </td>
          </tr>
          <td colspan="2" valign="top"  style="padding-left:500px;">
            Pembuat Laopran<br/><br/><br/>

            Mr
          </td>

        </table>
        <div class="tandatangan" >
          <br/>
          <b>CEO JAMBISPIRIT.COM</b><br/>
          <br/><br/><br/><br/><br/><hr/>
          Ronald Rusli  
        </div>
        <div class="tandatangan2">
          <br/>
          Jambi,
          25 Febuari 2011<br/><br/><br/><br/>
          <br />
          <br/><hr/>
          Mr. Y  
        </div>
      </body>
      </html>